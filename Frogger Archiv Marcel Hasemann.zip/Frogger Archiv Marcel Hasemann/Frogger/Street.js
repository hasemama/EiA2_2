var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class Street {
        draw() {
            //Gras
            Abschlussaufgabe.crc2.fillStyle = "green";
            Abschlussaufgabe.crc2.fillRect(0, 0, 800, 100);
            //Street
            Abschlussaufgabe.crc2.fillStyle = "grey";
            Abschlussaufgabe.crc2.fillRect(0, 100, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(100, 120, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(300, 120, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(500, 120, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(700, 120, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "#B43104";
            Abschlussaufgabe.crc2.fillRect(0, 150, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "grey";
            Abschlussaufgabe.crc2.fillRect(0, 200, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(50, 220, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(250, 220, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(450, 220, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(650, 220, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "#B43104";
            Abschlussaufgabe.crc2.fillRect(0, 250, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "grey";
            Abschlussaufgabe.crc2.fillRect(0, 300, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(100, 320, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(300, 320, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(500, 320, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(700, 320, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "#B43104";
            Abschlussaufgabe.crc2.fillRect(0, 350, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "grey";
            Abschlussaufgabe.crc2.fillRect(0, 400, 800, 50);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(50, 420, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(250, 420, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(450, 420, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "white";
            Abschlussaufgabe.crc2.fillRect(650, 420, 50, 10);
            Abschlussaufgabe.crc2.fillStyle = "green";
            Abschlussaufgabe.crc2.fillRect(0, 450, 800, 50);
            //Gras
            Abschlussaufgabe.crc2.fillStyle = "green";
            Abschlussaufgabe.crc2.fillRect(0, 500, 800, 100);
        }
    }
    Abschlussaufgabe.Street = Street;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=Street.js.map